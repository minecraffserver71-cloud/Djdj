package com.example.texthud;

/**
 * Represents a single text overlay: an id to reference it later,
 * a position, an ARGB color, and the text content itself.
 *
 * Positioning convention (like most Minecraft HUD elements):
 *  - x >= 0  -> measured from the left edge of the screen
 *  - x <  0  -> measured from the right edge of the screen (e.g. -10 = 10px from the right, text right-aligned there)
 *  - y >= 0  -> measured from the top edge of the screen
 *  - y <  0  -> measured from the bottom edge of the screen
 */
public class TextEntry {
    public String id;
    public int x;
    public int y;
    public int color; // ARGB, e.g. 0xFFFFFFFF = opaque white
    public String text;
    public boolean shadow;

    public TextEntry(String id, int x, int y, int color, String text, boolean shadow) {
        this.id = id;
        this.x = x;
        this.y = y;
        this.color = color;
        this.text = text;
        this.shadow = shadow;
    }
}
