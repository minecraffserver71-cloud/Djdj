package com.example.texthud;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;

import java.util.LinkedHashMap;
import java.util.Map;

public class TextHudMod implements ClientModInitializer {

    // id -> entry, LinkedHashMap so /texthud list keeps insertion order
    public static final Map<String, TextEntry> ENTRIES = new LinkedHashMap<>();

    @Override
    public void onInitializeClient() {
        TextHudCommands.register();

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.options.hudHidden) return;

            TextRenderer textRenderer = client.textRenderer;
            int screenWidth = client.getWindow().getScaledWidth();
            int screenHeight = client.getWindow().getScaledHeight();

            for (TextEntry entry : ENTRIES.values()) {
                int textWidth = textRenderer.getWidth(entry.text);
                int drawX = resolveCoord(entry.x, screenWidth, textWidth);
                int drawY = resolveCoord(entry.y, screenHeight, textRenderer.fontHeight);
                drawContext.drawText(textRenderer, entry.text, drawX, drawY, entry.color, entry.shadow);
            }
        });
    }

    // Negative coordinates are measured from the right/bottom edge instead of left/top
    private static int resolveCoord(int value, int screenSize, int elementSize) {
        if (value < 0) {
            return screenSize + value - elementSize;
        }
        return value;
    }
}
