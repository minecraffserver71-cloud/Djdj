package com.example.texthud;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.text.Text;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class TextHudCommands {

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(literal("texthud")

                // /texthud add <id> <x> <y> <color> <text...>
                .then(literal("add")
                    .then(argument("id", StringArgumentType.word())
                    .then(argument("x", IntegerArgumentType.integer())
                    .then(argument("y", IntegerArgumentType.integer())
                    .then(argument("color", StringArgumentType.word())
                    .then(argument("text", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            String id = StringArgumentType.getString(ctx, "id");
                            int x = IntegerArgumentType.getInteger(ctx, "x");
                            int y = IntegerArgumentType.getInteger(ctx, "y");
                            int color = ColorUtil.parse(StringArgumentType.getString(ctx, "color"));
                            String text = StringArgumentType.getString(ctx, "text");

                            TextHudMod.ENTRIES.put(id, new TextEntry(id, x, y, color, text, true));
                            ctx.getSource().sendFeedback(Text.literal("§aAdded overlay '" + id + "'"));
                            return 1;
                        })
                    ))))
                )

                // /texthud remove <id>
                .then(literal("remove")
                    .then(argument("id", StringArgumentType.word())
                        .executes(ctx -> {
                            String id = StringArgumentType.getString(ctx, "id");
                            if (TextHudMod.ENTRIES.remove(id) != null) {
                                ctx.getSource().sendFeedback(Text.literal("§aRemoved '" + id + "'"));
                            } else {
                                ctx.getSource().sendFeedback(Text.literal("§cNo overlay named '" + id + "'"));
                            }
                            return 1;
                        })
                    )
                )

                // /texthud clear
                .then(literal("clear")
                    .executes(ctx -> {
                        TextHudMod.ENTRIES.clear();
                        ctx.getSource().sendFeedback(Text.literal("§aCleared all overlays"));
                        return 1;
                    })
                )

                // /texthud list
                .then(literal("list")
                    .executes(ctx -> {
                        if (TextHudMod.ENTRIES.isEmpty()) {
                            ctx.getSource().sendFeedback(Text.literal("No active overlays"));
                        } else {
                            for (TextEntry e : TextHudMod.ENTRIES.values()) {
                                ctx.getSource().sendFeedback(Text.literal(
                                    "§7" + e.id + "§r: \"" + e.text + "\" @ (" + e.x + ", " + e.y + ")"));
                            }
                        }
                        return 1;
                    })
                )

                // /texthud move <id> <x> <y>
                .then(literal("move")
                    .then(argument("id", StringArgumentType.word())
                    .then(argument("x", IntegerArgumentType.integer())
                    .then(argument("y", IntegerArgumentType.integer())
                        .executes(ctx -> {
                            TextEntry e = TextHudMod.ENTRIES.get(StringArgumentType.getString(ctx, "id"));
                            if (e == null) {
                                ctx.getSource().sendFeedback(Text.literal("§cNo overlay with that id"));
                                return 0;
                            }
                            e.x = IntegerArgumentType.getInteger(ctx, "x");
                            e.y = IntegerArgumentType.getInteger(ctx, "y");
                            ctx.getSource().sendFeedback(Text.literal("§aMoved '" + e.id + "'"));
                            return 1;
                        })
                    ))
                )

                // /texthud color <id> <color>
                .then(literal("color")
                    .then(argument("id", StringArgumentType.word())
                    .then(argument("color", StringArgumentType.word())
                        .executes(ctx -> {
                            TextEntry e = TextHudMod.ENTRIES.get(StringArgumentType.getString(ctx, "id"));
                            if (e == null) {
                                ctx.getSource().sendFeedback(Text.literal("§cNo overlay with that id"));
                                return 0;
                            }
                            e.color = ColorUtil.parse(StringArgumentType.getString(ctx, "color"));
                            ctx.getSource().sendFeedback(Text.literal("§aUpdated color of '" + e.id + "'"));
                            return 1;
                        })
                    ))
                )

                // /texthud text <id> <text...>
                .then(literal("text")
                    .then(argument("id", StringArgumentType.word())
                    .then(argument("text", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            TextEntry e = TextHudMod.ENTRIES.get(StringArgumentType.getString(ctx, "id"));
                            if (e == null) {
                                ctx.getSource().sendFeedback(Text.literal("§cNo overlay with that id"));
                                return 0;
                            }
                            e.text = StringArgumentType.getString(ctx, "text");
                            ctx.getSource().sendFeedback(Text.literal("§aUpdated text of '" + e.id + "'"));
                            return 1;
                        })
                    ))
                )
            );
        });
    }
}
