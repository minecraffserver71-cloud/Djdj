package com.example.texthud;

import java.util.HashMap;
import java.util.Map;

/**
 * Parses color input from commands. Accepts:
 *  - Named colors: white, black, red, green, blue, yellow, cyan/aqua, magenta/pink,
 *    orange, gold, gray/grey, darkgray/darkgrey, purple
 *  - 6-digit hex RGB: "FF00FF" or "#FF00FF" (assumed fully opaque)
 *  - 8-digit hex ARGB: "80FF00FF" (custom alpha, e.g. semi-transparent)
 */
public class ColorUtil {
    private static final Map<String, Integer> NAMED_COLORS = new HashMap<>();

    static {
        NAMED_COLORS.put("white", 0xFFFFFFFF);
        NAMED_COLORS.put("black", 0xFF000000);
        NAMED_COLORS.put("red", 0xFFFF5555);
        NAMED_COLORS.put("green", 0xFF55FF55);
        NAMED_COLORS.put("blue", 0xFF5555FF);
        NAMED_COLORS.put("yellow", 0xFFFFFF55);
        NAMED_COLORS.put("cyan", 0xFF55FFFF);
        NAMED_COLORS.put("aqua", 0xFF55FFFF);
        NAMED_COLORS.put("magenta", 0xFFFF55FF);
        NAMED_COLORS.put("pink", 0xFFFF55FF);
        NAMED_COLORS.put("orange", 0xFFFFAA00);
        NAMED_COLORS.put("gold", 0xFFFFAA00);
        NAMED_COLORS.put("gray", 0xFFAAAAAA);
        NAMED_COLORS.put("grey", 0xFFAAAAAA);
        NAMED_COLORS.put("darkgray", 0xFF555555);
        NAMED_COLORS.put("darkgrey", 0xFF555555);
        NAMED_COLORS.put("purple", 0xFFAA00AA);
    }

    public static int parse(String input) {
        String raw = input.trim();
        String lower = raw.toLowerCase();

        if (NAMED_COLORS.containsKey(lower)) {
            return NAMED_COLORS.get(lower);
        }

        String hex = raw.startsWith("#") ? raw.substring(1) : raw;

        try {
            if (hex.length() == 6) {
                long rgb = Long.parseLong(hex, 16);
                return (int) (0xFF000000L | rgb);
            } else if (hex.length() == 8) {
                long argb = Long.parseLong(hex, 16);
                return (int) argb;
            }
        } catch (NumberFormatException ignored) {
            // fall through to default below
        }

        // Fallback if the input couldn't be parsed
        return 0xFFFFFFFF;
    }
}
