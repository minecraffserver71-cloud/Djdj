# Text HUD – Fabric Mod

Zeigt beliebig viele Textzeilen, an beliebiger Position, in beliebiger Farbe dauerhaft auf deinem Bildschirm an.
Läuft **komplett clientseitig** – funktioniert also auch auf Servern ohne dass der Server die Mod braucht.

Ziel: Minecraft **1.20.1**, Fabric Loader, Fabric API.

## Bauen

Voraussetzung: JDK 17 installiert.

```bash
./gradlew build
```

(Windows: `gradlew.bat build`)

Die fertige `.jar` findest du danach in `build/libs/texthud-1.0.0.jar`.

## Installation

1. [Fabric Loader](https://fabricmc.net/use/) für Minecraft 1.20.1 installieren.
2. [Fabric API](https://www.curseforge.com/minecraft/mc-mods/fabric-api) für 1.20.1 herunterladen und in deinen `mods`-Ordner legen.
3. Die selbst gebaute `texthud-1.0.0.jar` ebenfalls in den `mods`-Ordner legen.
4. Minecraft mit dem Fabric-Profil starten.

## Benutzung

Alle Befehle sind Client-Befehle (funktionieren im Singleplayer und auf jedem Server, auch ohne OP-Rechte).

```
/texthud add <id> <x> <y> <farbe> <text>
```
Fügt einen neuen Text-Overlay hinzu.

- `id` – eindeutiger Name, um den Text später zu ändern/löschen (z.B. `fps`, `zeile1`)
- `x`, `y` – Pixel-Position
  - positiv = von links/oben
  - negativ = von rechts/unten (z.B. `x = -10` heißt "10px vom rechten Rand")
- `farbe` – Name (`white`, `red`, `green`, `blue`, `yellow`, `cyan`, `pink`, `orange`, `gold`, `gray`, `purple`, `black`) **oder** Hex (`#FF00FF` bzw. mit Transparenz `80FF00FF`)
- `text` – der anzuzeigende Text (darf Leerzeichen enthalten)

### Beispiele

```
/texthud add zeile1 10 10 yellow Hallo Welt!
/texthud add zeile2 10 20 white Zweite Zeile
/texthud add ecke -10 -10 red Unten rechts
/texthud add custom 50 50 #00FFFF Türkiser Text
```

### Weitere Befehle

```
/texthud remove <id>          - entfernt einen Overlay
/texthud clear                - entfernt alle Overlays
/texthud list                 - listet alle aktiven Overlays
/texthud move <id> <x> <y>    - verschiebt einen bestehenden Overlay
/texthud color <id> <farbe>   - ändert die Farbe eines Overlays
/texthud text <id> <text>     - ändert den Text eines Overlays
```

Du kannst beliebig viele Overlays gleichzeitig anzeigen – einfach mehrfach `add` mit unterschiedlichen `id`s und `y`-Werten (z.B. 10, 20, 30, 40...) aufrufen, um mehrere Zeilen übereinander zu bekommen.

## Hinweis zu den Versionsnummern

Die Versionen in `gradle.properties` (Yarn-Mappings, Loader, Fabric API) passen zu 1.20.1. Falls Gradle beim Bauen meckert, dass eine Version nicht gefunden wird, schau kurz auf https://fabricmc.net/develop/ nach den aktuell empfohlenen Werten und trage sie dort ein – der restliche Code bleibt unverändert.
